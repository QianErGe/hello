/* 初始化测试程序的mysql
 * 1 从线上数据库中获取300条数据 取出raw字段
 * 2 截取row字段，获取其中的user_privilege
 * 3 将其中两项，做为新的数据，插入到数据库中
 */
 #include "init_mysql.h"
 void CMysql__::vInit( int iNum )
{
	cout << "start" << endl;
	char* pBody = NULL;
	long iLen = 0;

	vSelect( &pBody, &iLen, iNum );
	if ( pBody == NULL )
	{
		return ;
	}
	// 前4字节是二进制
	int i = 0;
	int* p = &i;
	memcpy( p, pBody, 4);
	logger( "the str len:%d", *p );

	char szStr[ 1024*5 ] = {0};
	memcpy( szStr, pBody+4, *p );

	free(pBody);
	pBody = NULL;

	cout << szStr << endl;
	m_json.reset();
 	m_json.update( szStr );


 	vector< acl::json_node* >::const_iterator cit;
	acl::json_node* pNode = NULL;

	acl::string szUserIdCount;
	szUserIdCount.clear();
	// get the user_id
	const vector<acl::json_node*>& elements = m_json.getElementsByTagName("user_id");
	if ( !elements.empty() )  
	{
		cit      = elements.begin();
		pNode    = *cit;
		if ( pNode )
		{
			// judge the style true or false
			logger( "tagname:%s, text:%s", pNode->tag_name() ? pNode->tag_name() : "", pNode->get_text() ? pNode->get_text() : "" );
			szUserIdCount.clear();
			szUserIdCount.format( "%s", pNode->get_text() );
			cout << "user_id:" << pNode->get_text() << endl; 
			if ( m_Mysql.bUpdate( iNum, szUserIdCount ) )
				cout << "update success id:" << iNum << endl;
		}
	}
	else
	{
		logger_error("analysis the http's one_user_id_size failed, there's no field");
	}
}

void CMysql__::vSelect( OUT char** pBody, OUT long* pLen, IN int iNum )
{
	const char* pSql_fmt = " select raw from ams_test where id = %d ;";
	acl::string szSql;
 	szSql.format( pSql_fmt, iNum);

 	int iRet = 0;

	iRet = mysql_real_query( &m_MyConn, szSql.c_str(), szSql.size() );
	if ( !iRet )
	{
		m_Result = mysql_store_result(&m_MyConn);
		if ( m_Result == NULL )
		{
			logger_error( "select failed ..." );
		}
		m_Row = mysql_fetch_row(m_Result);
		unsigned long* uLen = mysql_fetch_lengths(m_Result);
		if (uLen == NULL)
		{	
			logger_error( "select error uLen is NULL ");
		}
		else
		{
			*pBody = (char*)malloc( uLen[0] + 1 );
			if (*pBody == NULL)
			{
				logger_error( "malloc error" );
				return ;
			}
			memset(*pBody, 0, uLen[0]);
			memcpy( *pBody, m_Row[0], uLen[0]);

			// szRaw.format("%s", szcRaw);
			*pLen = uLen[0];
			logger("select success...:%ld...sql:%s", uLen[0], szSql.c_str() );

			mysql_free_result(m_Result);
		}
		
	}
	else
	{
		logger_error( "select error ... " );
	}	
}

