#include "stdafx.h"
#include "http_servlet.h"

#include "http_parse.h"
#include "http_cmd_test.h"
#include "http_redis.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
using namespace std;
http_servlet::http_servlet(acl::socket_stream* stream, acl::session* session)
: acl::HttpServlet(stream, session)
{

}

http_servlet::~http_servlet(void)
{

}

bool http_servlet::doError(acl::HttpServletRequest&,
	acl::HttpServletResponse& res)
{
	res.setStatus(400);
	res.setContentType("text/html; charset=");
	// ���� http ��Ӧͷ
	if (res.sendHeader() == false)
		return false;

	// ���� http ��Ӧ��
	acl::string buf;
	buf.format("<root error='some error happened!' />\r\n");
	(void) res.getOutputStream().write(buf);
	return false;
}

bool http_servlet::doOther(acl::HttpServletRequest&,
	acl::HttpServletResponse& res, const char* method)
{
	res.setStatus(400);
	res.setContentType("text/html; charset=");
	// ���� http ��Ӧͷ
	if (res.sendHeader() == false)
		return false;
	// ���� http ��Ӧ��
	acl::string buf;
	buf.format("<root error='unkown request method %s' />\r\n", method);
	(void) res.getOutputStream().write(buf);
	return false;
}

bool http_servlet::doGet(acl::HttpServletRequest& req,
	acl::HttpServletResponse& res)
{
	return doPost(req, res);
}

bool http_servlet::doPost(acl::HttpServletRequest& req,
	acl::HttpServletResponse& res)
{
	// ���� xml ��ʽ��������
	acl::xml1 http_body;
	acl::string xml_buf;
	char szBody[MAX_BODY_LEN+1] = {0}; 

	http_body.build_xml(xml_buf);
	// add zhaoq 20160712
	/* 1 get the http's header, according the header choose the diff way */
	const char* pName 		  = "request_code";
	const char* pDevId 		  = "dev_id";
	const char* pTransId      = "trans_id";
	const char* pValueName 	  = NULL;
	const char* pValueDevId   = NULL;
	const char* pValueTransId = NULL;

	pValueName 	  = req.getHeader( pName );
	pValueDevId   = req.getHeader( pDevId );
	
	if ( pValueName == NULL || pValueDevId == NULL )
	{
		logger_fatal( "the request_code is null" );
		return false;
	}

	logger( "the request_code is:%s", pValueName );


	// 2 judge the value
	if ( strcmp(pValueName, "receive_cmd") == 0 )
	{
		logger( "===================receive_cmd===================");
		CCmdTest cTest;
		CRedis redis1;
		acl::string szCmdCode;


		void* pBody = NULL;
		long  lLen = 0;
		cTest.vDealHttp( pValueDevId, &pBody, &lLen );
		res.setHeader( "response_code", cTest.m_szResponsCode );
	    res.setContentType("application/octet-stream");
		res.setContentLength( lLen );
		res.setHeader( "cmd_code", cTest.m_szCmdCode );
		res.setHeader( "trans_id", cTest.m_szTransId );
		res.setHeader( "name", cTest.m_Test );

		if ( pBody != NULL )
		{
			res.write( pBody, lLen );

			printf( "....%s...%ld", (char*)pBody, lLen );
			char szTmp[5] = {0};
			int iNUm = 0;
			int* p = &iNUm;
			memcpy( p, pBody, 4);
			memcpy( szTmp, pBody, 4);
			logger( "http_body:%s, http_body_len:%ld, ////%d, %s", (char*)pBody+4, lLen, *p, szTmp  );

			free(pBody);
			pBody = NULL;
		}
		else
		{
			logger( "no http_body..." );
		}
		return res.write(NULL, 0);
	}
	else if ( strcmp(pValueName, "send_cmd_result") == 0 )
	{
		logger( "===================send_cmd_result===================");
		logger( "....%s....", pValueName );
		const char* pResCode = req.getHeader( "cmd_return_code" );
		pValueTransId = req.getHeader( pTransId ); 
		res.setHeader( "trans_id", pValueTransId);
		CResponse cRes;
		if ( strcmp(pResCode, "OK") == 0 )
		{
			cRes.bDelRedis( pValueDevId );
			logger( "exec success as dev_id:%s, trans_id:%s", pValueDevId, pValueTransId );
			// result�п��ܴ�����Ϣ�壬��Ҫ������Ϣ��
			long long int iConLen = req.getContentLength();
			if ( iConLen <= 0 )
			{
				logger( "the result come back without http_body" );
			}
			else
			{
				logger( "this result come back with http_body len:%lld ...", iConLen );
				acl::istream& in=req.getInputStream();
				in.read( szBody, sizeof(szBody),false );
				bool bRes = cRes.bParse( szBody, sizeof(szBody) );
				if ( !bRes )
				{
					logger_error( "parse http_response error ... " );
					res.setHeader( "response_code", "OK");
					return res.write(xml_buf) && res.write(NULL, 0);
				}
			}
			res.setHeader( "response_code", "OK");
			return res.write(xml_buf) && res.write(NULL, 0);
		}
		logger_error( "exec failed as dev_id:%s, trans_id:%s", pValueDevId, pValueTransId );
		// try again? 
		res.setHeader( "response_code", "ERROR");
		res.setHeader( "trans_id", pValueTransId);
		return res.write(xml_buf) && res.write(NULL, 0);
	}
	else if ( strcmp(pValueName, "realtime_glog") == 0 )
	{
		logger( "===================realtime_glog===================");
		res.setHeader( "response_code", "OK");
		return  res.write(xml_buf) && res.write(NULL, 0);
		/* ͨ��ָ��ʶ��ͨ���������û��򿨣� */
		// get the body . for the bin_1 ...
		acl::istream& in=req.getInputStream();
		in.read( szBody, sizeof(szBody),false ); // �����ݵ���Ϣ�����

		CRealtimeGlog cGlog( szBody, sizeof(szBody) );
		bool bRes = cGlog.bParse();
		if ( !bRes )
		{
			// response err
			logger_error("parse realtime_glog's body error ....");
			res.setHeader( "response_code", "ERROR" );
			return  res.write(xml_buf) && res.write(NULL, 0);
		}
		// response ok
		logger("response ok...");
		res.setHeader( "response_code", "OK" );
		return  res.write(xml_buf) && res.write(NULL, 0);
	}
	else if ( strcmp(pValueName, "realtime_enroll_data") == 0 )
	{
		logger( "===================realtime_enroll_data===================");
		res.setHeader( "response_code", "OK");
		return  res.write(xml_buf) && res.write(NULL, 0);
		/* ���û�ע�ᣬ�Ǽ� */
		acl::istream& in=req.getInputStream();
		in.read( szBody, sizeof(szBody),false ); // �����ݵ���Ϣ�����

		CEnrollData cEnroll( szBody, sizeof(szBody) );
		bool bRes = cEnroll.bParse();
		if ( !bRes )
		{
			// response err
			logger_error("parse realtime_glog's body error ....");
			res.setHeader( "response_code", "ERROR" );
			return  res.write(xml_buf) && res.write(NULL, 0);
		}
		// response ok
		logger("response ok...");
		res.setHeader( "response_code", "OK" );
		return  res.write(xml_buf) && res.write(NULL, 0);
	}	
	else 
	{
		logger( "-------------------unkown value-------------------");
		logger_error( "unkown value :%s", pValueName );
		return res.write(xml_buf) && res.write(NULL, 0);
		// return 
	} 





	res.setContentType("text/xml; charset=utf-8")	// ������Ӧ�ַ���
		.setKeepAlive(req.isKeepAlive())	// �����Ƿ񱣳ֳ�����
		.setContentEncoding(true)		// �Զ�֧��ѹ������
		.setChunkedTransferEncoding(true);	// ���� chunk ���䷽ʽ

	const char* param1 = req.getParameter("name1");
	const char* param2 = req.getParameter("name2");

	// ���� xml ��ʽ��������
	acl::xml1 body;
	body.get_root()
		.add_child("root", true)
			.add_child("params", true)
				.add_child("param", true)
					.add_attr("name1", param1 ? param1 : "null")
				.get_parent()
				.add_child("param", true)
					.add_attr("name2", param2 ? param2 : "null");
	acl::string buf;
	body.build_xml(buf);

	// ���� http ��Ӧ�壬��Ϊ������ chunk ����ģʽ��������Ҫ�����һ��
	// res.write ������������Ϊ 0 �Ա�ʾ chunk �������ݽ���
	return res.write(buf) && res.write(NULL, 0);
}
