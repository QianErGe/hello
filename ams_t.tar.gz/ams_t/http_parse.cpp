/* @ brief:处理http消息
 * 
 * @writer zhaoq
 * @date: 2016.07.13
 */
using namespace std;

#include "http_parse.h"

CEnrollData::CEnrollData( const char* pBody, unsigned int iLen ):CHttpParse( pBody, iLen )
{
}
CEnrollData::~CEnrollData()
{
}
bool CEnrollData::bParse()
{
	vector< acl::json_node* >::const_iterator cit;
	acl::json_node* pNode = NULL;
	bool bRes = true;
	acl::string szUserId, szUserName, szUserPhoto, szUserPrivilege, szEnrollData;
	szUserId.clear();
	szUserName.clear();
	szUserPhoto.clear();
	szUserPrivilege.clear();
	szEnrollData.clear();

	// get the user_id
	const vector<acl::json_node*>& elements = m_json.getElementsByTagName("user_id");
	if ( !elements.empty() )  
	{
		cit      = elements.begin();
		pNode    = *cit;
		if ( pNode )
		{
			// judge the style true or false
			logger( "tagname:%s, text:%s", pNode->tag_name() ? pNode->tag_name() : "", pNode->get_text() ? pNode->get_text() : "" );
			szUserId.format( "%s", pNode->get_text() );
		}
	}
	else
	{
		logger_error("analysis the http's user_id failed, there's no field");
		bRes = false;
	}
	

	// get the user_name
	const vector<acl::json_node*>& elements_verfy = m_json.getElementsByTagName("user_name");
	if ( !elements_verfy.empty() )
	{
		cit      = elements_verfy.begin();
		pNode 	 = *cit;
		if ( pNode )
		{
			// judge the style true or false
			logger( "tagname:%s, text:%s", pNode->tag_name() ? pNode->tag_name() : "", pNode->get_text() ? pNode->get_text() : "" );
			szUserName.format( "%s", pNode->get_text() );
		}
	}
	else
	{
		logger_error("analysis the http's user_name failed, there's no field");
		bRes = false;
	}
	
	// get the user_privilege
	const vector<acl::json_node*>& elements_io_mode  = m_json.getElementsByTagName("user_privilege");
	if ( !elements_io_mode.empty() )
	{
		cit      = elements_io_mode.begin();
		pNode 	 = *cit;
		if ( pNode )
		{
			// judge the style true or false
			logger( "tagname:%s, text:%s", pNode->tag_name() ? pNode->tag_name() : "", pNode->get_text() ? pNode->get_text() : "" );
			szUserPrivilege.format( "%s", pNode->get_text() );
		}
	}
	else
	{
		logger_error("analysis the http's user_privilege failed, there's no field");
		bRes = false;
	}

	// get the user_photo
	const vector<acl::json_node*>& elements_io_time  = m_json.getElementsByTagName("user_photo");
	if ( !elements_io_time.empty() )
	{
		cit      = elements_io_time.begin();
		pNode 	 = *cit;
		if ( pNode )
		{
			// judge the style true or false
			logger( "tagname:%s, text:%s", pNode->tag_name() ? pNode->tag_name() : "", pNode->get_text() ? pNode->get_text() : "" );
			szUserPhoto.format( "%s", pNode->get_text() );
		}
	}
	else
	{
		logger_error("analysis the http's user_photo failed, there's no field");
		bRes = false;
	}

	// get the enroll_data_array
	const vector<acl::json_node*>& elements_io_image  = m_json.getElementsByTagName("enroll_data_array");
	if ( !elements_io_image.empty() )
	{
		cit = elements_io_image.begin();
		for (; cit != elements_io_image.end(); ++cit)
		{
			acl::json_node* node = (*cit)->first_child();
			printf("tag: %s\r\n", (*cit)->tag_name());
			while (node)
			{
				acl::json_node* nv = node->first_child();
				while (nv)
				{
					printf("tag: %s, value: %s; ", nv->tag_name(), nv->get_text());
					szEnrollData.format( "%s", nv->get_text() );
					nv = node->next_child();
				}
				printf("\r\n");
				node = (*cit)->next_child();
			}
		}
	}
	else
	{
		logger_error("analysis the http's enroll_data_array failed, there's no field");
		bRes = false;
	}
	// 将解析后的消息体，插入到数据库中
	if ( m_Mysql.bInsert( szUserId, szUserName, szUserPrivilege, szUserPhoto, szEnrollData ) )
		logger( "Insert into mysql success ... " );
	logger(" the body is:%s\n", m_szBody);
	return bRes;
}

CRealtimeGlog::CRealtimeGlog( const char* pBody, unsigned int iLen ):CHttpParse( pBody, iLen )
{
}
CRealtimeGlog::~CRealtimeGlog()
{
}
bool CRealtimeGlog::bParse()
{
	vector< acl::json_node* >::const_iterator cit;
	acl::json_node* pNode = NULL;
	bool bRes = true;

	acl::string szUserId, szVerifyMode, szIoMode, szIoTime, szIoImage;
	szUserId.clear();
	szVerifyMode.clear();
	szIoMode.clear();
	szIoTime.clear();
	szIoImage.clear();

	// get the user_id
	const vector<acl::json_node*>& elements = m_json.getElementsByTagName("user_id");
	if ( !elements.empty() )  
	{
		cit      = elements.begin();
		pNode    = *cit;
		if ( pNode )
		{
			// judge the style true or false
			logger( "tagname:%s, text:%s", pNode->tag_name() ? pNode->tag_name() : "", pNode->get_text() ? pNode->get_text() : "" );
			szUserId.format( "%s", pNode->get_text() );
		}
	}
	else
	{
		logger_error("analysis the http's user_id failed, there's no field");
		bRes = false;
	}
	
	// get the verfy_mode
	const vector<acl::json_node*>& elements_verfy = m_json.getElementsByTagName("verify_mode");
	if ( !elements_verfy.empty() )
	{
		cit      = elements_verfy.begin();
		pNode 	 = (*cit)->first_child();
		printf("tag: %s\r\n", (*cit)->tag_name());
		while( pNode )
		{
			acl::json_node* nv = pNode->first_child();
			while(nv)
			{
				logger("tag:%s, value:%s\n", nv->tag_name()?nv->tag_name():"", nv->get_text()?nv->get_text():"");
				szVerifyMode.format( "%s", nv->get_text() );
				nv = pNode->next_child();
			}
			pNode = (*cit)->next_child();
		}
	}
	else
	{
		logger_error("analysis the http's verify_mode failed, there's no field");
		bRes = false;
	}
	
	// get the io_mode
	const vector<acl::json_node*>& elements_io_mode  = m_json.getElementsByTagName("io_mode");
	if ( !elements_io_mode.empty() )
	{
		cit      = elements_io_mode.begin();
		pNode 	 = *cit;
		if ( pNode )
		{
			// judge the style true or false
			logger( "tagname:%s, text:%s", pNode->tag_name() ? pNode->tag_name() : "", pNode->get_text() ? pNode->get_text() : "" );
			szIoMode.format( "%s", pNode->get_text() );
		}
	}
	else
	{
		logger_error("analysis the http's io_mode failed, there's no field");
		bRes = false;
	}

	// get the io_time
	const vector<acl::json_node*>& elements_io_time  = m_json.getElementsByTagName("io_time");
	if ( !elements_io_time.empty() )
	{
		cit      = elements_io_time.begin();
		pNode 	 = *cit;
		if ( pNode )
		{
			// judge the style true or false
			logger( "tagname:%s, text:%s", pNode->tag_name() ? pNode->tag_name() : "", pNode->get_text() ? pNode->get_text() : "" );
			szIoTime.format( "%s", pNode->get_text() );
		}
	}
	else
	{
		logger_error("analysis the http's io_time failed, there's no field");
		bRes = false;
	}

	// get the io_image
	const vector<acl::json_node*>& elements_io_image  = m_json.getElementsByTagName("io_image");
	if ( !elements_io_image.empty() )
	{
		cit      = elements_io_image.begin();
		pNode 	 = *cit;
		if ( pNode )
		{
			// judge the style true or false
			logger( "tagname:%s, text:%s", pNode->tag_name() ? pNode->tag_name() : "", pNode->get_text() ? pNode->get_text() : "" );
			szIoImage.format( "%s", pNode->get_text() );
		}
	}
	else
	{
		logger_error("analysis the http's io_image failed, there's no field");
		bRes = false;
	}
	printf(" the body is:%s\n", m_szBody);
	// 将数据写入mysql数据库
	if ( m_Mysql.bInsert( szUserId, szVerifyMode, szIoMode, szIoTime, szIoImage, 1 ) )
	{
		logger( "insert into mysql success ... " );
	}
	else
	{
		logger_error( "insert into mysql failed ... " );
	}
	return bRes;
}

CResponse::CResponse() {}
CResponse::~CResponse(){}
bool CResponse::bDelRedis( acl::string szKey )
{
	// 查询redis2中是否存在该key(正常情况下应该存在)
	acl::string szKey2;
 	szKey2.format("%s%s", szKey.c_str(), "_2");
	if ( !m_Redis.bExists(szKey2) )
	{
		logger_error( "redis2 do not has the key:%s", szKey2.c_str() );
		return false;
	}
	else
	{
		if ( m_Redis.bDelKey(szKey2) )
		{
			logger( "redis2 delete the key:%s success ... ",szKey2.c_str() );
			return true;
		}
		logger_error( "redis2 delete the key:%s failed ... ",szKey2.c_str() );
		return false;
	}
}
bool CResponse::bParse( const char* pBody, unsigned int iLen )
{
	memset( m_szBody, 0, sizeof(m_szBody) );
 	if ( pBody != NULL )
 	{
 		if ( iLen > sizeof(m_szBody) )
 		{
 			iLen = sizeof(m_szBody);
 		}
 		// 1 截取前4个字节，打印结果是否为255
 		int iNum = 0;
 		int* pStrLen = &iNum;
 		memcpy( pStrLen, pBody, 4 );
 		logger( "~~~~~~~~~~~~~~the strlen :%d", *pStrLen );
 		// 2 取出后面的json ，并获取每一个的值
 		char szStr[1025] = {0};
 		memcpy( szStr, pBody+4, *pStrLen );
 		m_json.update( szStr );
	}

	vector< acl::json_node* >::const_iterator cit;
	acl::json_node* pNode = NULL;
	bool bRes = true;

	acl::string szUserId, szUserPrivilege;
	szUserId.clear();
	szUserPrivilege.clear();
	// get the user_id
	const vector<acl::json_node*>& elements = m_json.getElementsByTagName("user_id");
	if ( !elements.empty() )  
	{
		cit      = elements.begin();
		pNode    = *cit;
		if ( pNode )
		{
			// judge the style true or false
			logger( "tagname:%s, text:%s", pNode->tag_name() ? pNode->tag_name() : "", pNode->get_text() ? pNode->get_text() : "" );
			szUserId.format( "%s", pNode->get_text() );
		}
	}
	else
	{
		logger_error("analysis the http's user_id failed, there's no field");
		bRes = false;
	}

	// get user_privilege
	const vector<acl::json_node*>& elements1 = m_json.getElementsByTagName("user_privilege");
	if ( !elements1.empty() )  
	{
		cit      = elements1.begin();
		pNode    = *cit;
		if ( pNode )
		{
			// judge the style true or false
			logger( "tagname:%s, text:%s", pNode->tag_name() ? pNode->tag_name() : "", pNode->get_text() ? pNode->get_text() : "" );
			szUserPrivilege.format( "%s", pNode->get_text() );
		}
	}
	else
	{
		logger_error("analysis the http's user_privilege failed, there's no field");
		bRes = false;
	}

	// 对比是否为manager即可
	if ( strcmp(szUserPrivilege.c_str(), "MANAGER") == 0 )
	{
		logger( "equal with the mysql user_id:%s, user_privilege:%s", szUserId.c_str(), szUserPrivilege.c_str() );
		bRes = true;
	}
	else
	{
		logger_error( "not equal with the mysql user_id:%s, machine_privilege:%s", szUserId.c_str(), szUserPrivilege.c_str() );
		bRes = false;
	}

#if 0
	// 对比mysql，数据是否一致。该逻辑应当剥离出去，暂时这么处理
	acl::string szMysqlPrivilege;
	m_Mysql.vSelect( szUserId, szMysqlPrivilege );
	if ( strcmp(szUserPrivilege.c_str(), szMysqlPrivilege.c_str()) == 0 )
	{
		logger( "equal with the mysql user_id:%s, user_privilege:%s", szUserId.c_str(), szUserPrivilege.c_str());
		bRes = true;
	}
	else
	{
		logger_error( "not equal with the mysql user_id:%s, machine_privilege:%s, mysql_privilege:%s", szUserId.c_str(), szUserPrivilege.c_str(), szMysqlPrivilege.c_str() );
		bRes = false;
	}
#endif 
	return bRes;
}










