/*
 * @brief:服务器接受到机器指令后，将队列中的待执行指令回复给机器
 * @测试程序
 * @writer:zhaoq
 * @date:2016-07-14
 */
 #ifndef __HTTP_CMD_TEST_H__
 #define __HTTP_CMD_TEST_H__
#include <vector>
#include "stdafx.h"
#include "http_servlet.h"
#include "http_redis.h"
#include "http_mysql.h"
#include "acl_cpp/stdlib/json.hpp"

#if 0
1、 <考勤机>连接9777接口，发送命令请求 receive_cmd
2、 <服务端> 连续同步300人 （SET_USER_INFO） 
3、<服务端>随机修改20人员为管理员权限，同步到考勤机(SET_USER_PRIVILEGE)
4、 <服务端> 获取考勤机上所有人员，比对跟上传的是否一致 （GET_USER_INFO）
5、<服务端>清除登记所有数据(CLEAR_ENROLL_DATA)
6、<服务端>发送测试成功指令
7、连续在线时长18小时。
8、<服务端>发送重新启动命令(RESET_FK)


需要确认的：
GET_DEVICE_STATUS（服务器可以主动获取机器上的数据，可以选择全部或者是未上传的数据）
GET_LOG_DATA （已经更改为心跳）

Wifi稳定性和可靠性测试，验证机器跟服务器通信协议的兼容性和可靠性，异常处理。
方法：测试程序根据双方约定的步骤，加入mac验证物理网线和无线地址检测。
机器预存测试ssid和密码，上电后的测试逻辑全部在服务器，测试通过后服务器发送命令告诉成功加入时间戳。
#endif

class CCmdTest
{
public:
	CCmdTest();
	~CCmdTest();
	/*@ brief:对外接口，处理http
	 *@ param szKey  设备id
	 *@ param szBody 组建的消息体
	 *@ return 
	 *@ see:
	 **/
	void vDealHttp( acl::string szKey, void** pBody, long* pLen );

private:
	/*@ brief:判断考勤机是否在线18小时
	 *@ param szKey  设备id
	 *@ return 
	 *@ see:
	 **/
	void vJudgeTime( acl::string szKey );

	/*@ brief: 初始化数据 (mysql/redis)
	 *@ param szKey  设备id
	 *@ return 
	 *@ see:
	 **/
	void vInit( acl::string szKey );

	/*@ brief: 取出队列中的命令，查询相关数据库，组建消息体
	 *@ param szKey   设备id
	 *@ param szValue 执行命令
	 *@ param szBody  组建消息体
	 *@ see:
	 **/
	void vBuildBody( acl::string& szKey, acl::string& szValue, void** pBody, long* pLen );

	

	void vForDiffBody( acl::string& szBody, void** pBody, long* pLen );

	CRedis m_Redis1; 			  // 队列，要执行的命令
	CRedis m_Redis2; 			  // redis哈希，重发队列
	CRedis m_Redis3;			  // 监测重启队列
	CMysql m_Mysql;				  // mysql
	CMysql_ m_Mysql_;
	
public:
	acl::string m_szCmdCode;      // 机器执行码
	acl::string m_szResponsCode;  // 响应码
	acl::string m_szTransId;      // 任务id
	acl::string m_Test;
};


 #endif // __HTTP_CMD_TEST_H__