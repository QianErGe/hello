/*@ brief:封装mysql操作
 *@
 *@ writer: zhaoq
 *@ date: 2016-07-16
 *@
 */
 #include "http_mysql.h"
 
 bool CMysql::bCreate()
 {
 	const char* pCreate = "CREATE TABLE `enrollment` (`id` int(11) unsigned NOT NULL AUTO_INCREMENT, \r\n"
 				" `enroll_data` mediumblob, \r\n"
 				" `user_id` char(16) DEFAULT NULL, \r\n"
 				" `user_name` char(64) DEFAULT NULL, \r\n"
 				" `user_privilege` char(64) DEFAULT NULL, \r\n"
 				" `user_photo` varchar(64) DEFAULT NULL, \r\n"
 				" `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,\r\n"
				" PRIMARY KEY (`id`)) ENGINE=MyISAM AUTO_INCREMENT=15241 DEFAULT CHARSET=utf8";
	const char* pCreateGlog = "CREATE TABLE `user_glog` (`id` int(11) unsigned NOT NULL AUTO_INCREMENT, \r\n"
 				" `user_id` char(16) DEFAULT NULL, \r\n"
 				" `verify_mode` char(64) DEFAULT NULL, \r\n"
 				" `io_mode` char(64) DEFAULT NULL, \r\n"
 				" `io_time` varchar(64) DEFAULT NULL, \r\n"
 				" `io_image` varchar(64) DEFAULT NULL, \r\n"
 				" `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,\r\n"
				" PRIMARY KEY (`id`)) ENGINE=MyISAM AUTO_INCREMENT=15241 DEFAULT CHARSET=utf8";
 	if ( m_Db.tbl_exists("enrollment") )
 	{
 		logger( "The Table:%s exist ...", "enrollment" );
 		return true;
 	}
 	else 
 	{
 		if ( m_Db.sql_update(pCreate) == false )
 		{
 			logger_error( " Create Table:%s failed ...", "enrollment" );
 			return false;
 		}
 		if ( m_Db.sql_update(pCreateGlog) == false )
 		{
 			logger_error( "Create Table:%s failed ...", "user_glog" );
 			return false;
 		}
 		logger( "Create Table:%s, Table:%s success...", "enrollment", "user_glog" );
 		return true;
 	}
 }
 // enrollment
 bool CMysql::bInsert( acl::string szUserId, acl::string szUserName, acl::string szUserPrivilege, acl::string szUserPhoto, acl::string szEnrollData )
 {
 	const char* pSql_fmt = " insert into enrollment (user_id, user_name, user_privilege, user_photo, enroll_data) values ( '%s', '%s', '%s', '%s', '%s'); ";
 	acl::string szSql;
 	szSql.format( pSql_fmt, szUserId.c_str(), szUserName.c_str(), szUserPrivilege.c_str(), szUserPhoto.c_str(), szEnrollData.c_str() );
 	if ( !m_Db.sql_update(szSql.c_str()) )
 	{
 		logger_error( "Insert into table failed ... user_id:%s", szUserId.c_str() );
 		return false;
 	}
 	logger( "Insert into table success ... user_id:%s", szUserId.c_str() );
 	return true;
 }
 // user_glog
 bool CMysql::bInsert( acl::string szUserId, acl::string szVerifyMode, acl::string szIoMode, acl::string szIoTime, acl::string szIoImage, int iFlag )
 {
 	printf( "iFlag:%d", iFlag );
 	const char* pSql_fmt = " insert into user_glog (user_id, verify_mode, io_mode, io_time, io_image) values ( '%s', '%s', '%s', '%s', '%s'); ";
 	acl::string szSql;
 	szSql.format( pSql_fmt, szUserId.c_str(), szVerifyMode.c_str(), szIoMode.c_str(), szIoTime.c_str(), szIoImage.c_str() );
 	if ( !m_Db.sql_update(szSql.c_str()) )
 	{
 		logger_error( "Insert into table:user_glog failed ... user_id:%s", szUserId.c_str() );
 		return false;
 	}
 	logger( "Insert into table:user_glog success ... user_id:%s", szUserId.c_str() );
 	return true;
 }
 bool CMysql::bDelete( acl::string szUserId )
 {
 	const char* pSql_fmt = " delete from ams_test where user_id = '%s';";
 	acl::string szSql;
 	szSql.format( pSql_fmt, szUserId.c_str() );
 	if ( !m_Db.sql_update(szSql.c_str()) )
 	{
 		logger_error( "delete failed ... user_id:%s", szUserId.c_str() );
 		return false;
 	}
 	logger( "delete success ... user_id:%s", szUserId.c_str() );
 	return true;
 }
 bool CMysql::bUpdate( acl::string szUserId, acl::string szUserPrivilege )
 {
 	// 
 	const char* pSql_fmt = " update ams_test set privilege ='%s' where user_id = '%s';";
 	acl::string szSql;
 	szSql.format( pSql_fmt, szUserPrivilege.c_str(), szUserId.c_str() );
 	if ( !m_Db.sql_update(szSql.c_str()) )
 	{
 		logger_error( "update table failed ... user_id:%s", szUserId.c_str() );
 		return false;
 	}
 	logger( "Update table success ... user_id:%s", szUserId.c_str() );
 	return true;
 }
 bool CMysql::bUpdate( int iId, acl::string szUserPrivilege )
 {
 	const char* pSql_fmt = "update ams_test set user_id='%s' where id = '%d';";
 	acl::string szSql;
 	szSql.format( pSql_fmt, szUserPrivilege.c_str(), iId );
 	if ( !m_Db.sql_update(szSql.c_str()) )
 	{
 		logger_error( "update table failed ... id:%d", iId );
 		return false;
 	}
 	logger( "Update table success ... id:%d", iId );
 	return true;
 }
 void CMysql::vSelect( IN acl::string szUserId, OUT acl::string& szUserName, OUT acl::string& szUserPrivilege, OUT acl::string& szUserPhoto, OUT acl::string& szEnrollData  )
 {
 	const char* pSql_fmt = " select * from enrollment where user_id = '%s' ;";
 	acl::string szSql;
 	szSql.format( pSql_fmt, szUserId.c_str() );
 	if ( !m_Db.sql_select(szSql) )
 	{
 		logger_error( "select error ... user_id:%s", szUserId.c_str() );
 	}
 	// 返回查询结果
	const acl::db_rows* result = m_Db.get_result();
	if (result)
	{
		const std::vector<acl::db_row*>& rows = result->get_rows();
		for (size_t i = 0; i < rows.size(); i++)
		{
			const acl::db_row* row = rows[i];
			szEnrollData    = (*row)[1];
			szUserName      = (*row)[3];
			szUserPrivilege = (*row)[4];
			szUserPhoto     = (*row)[5];
		}
	}
	
 	logger( "mysql-> szUserId:%s, szUserName:%s, szUserPhoto:%s, szUserPrivilege:%s, szEnrollData:%s", szUserId.c_str(), szUserName.c_str(), szUserPhoto.c_str(), szUserPrivilege.c_str(), szEnrollData.c_str() );
 }

 void CMysql::vSelect( IN acl::string szUserId, OUT acl::string& szUserPrivilege )
 {
 	const char* pSql_fmt = " select * from ams_test where user_id = '%s' ;";
 	acl::string szSql;
 	szSql.format( pSql_fmt, szUserId.c_str() );
 	if ( !m_Db.sql_select(szSql) )
 	{
 		logger_error( "select error ... user_id:%s", szUserId.c_str() );
 	}
 	// 返回查询结果
	const acl::db_rows* result = m_Db.get_result();
	if (result)
	{
		const std::vector<acl::db_row*>& rows = result->get_rows();
		for (size_t i = 0; i < rows.size(); i++)
		{
			const acl::db_row* row = rows[i];
			szUserPrivilege    = (*row)[3];
			logger( "user_id:%s", (*row)[1] );
		}
	}
	logger( "mysql-> user_id:%s user_privilege:%s", szUserId.c_str(), szUserPrivilege.c_str() );
 }
 void CMysql::vSelect( IN int iId, OUT acl::string& szUserId )
 {
 	const char* pSql_fmt = " select * from ams_test where id = '%d' ;";
 	acl::string szSql;
 	szSql.format( pSql_fmt, iId );
 	if ( !m_Db.sql_select(szSql) )
 	{
 		logger_error( "select error ... id:%d", iId );
 	}
 	// 返回查询结果
	const acl::db_rows* result = m_Db.get_result();
	if (result)
	{
		const std::vector<acl::db_row*>& rows = result->get_rows();
		for (size_t i = 0; i < rows.size(); i++)
		{
			const acl::db_row* row = rows[i];
			szUserId    = (*row)[1];
			logger( "user_id:%s", (*row)[1] );
		}
	}
	logger( "mysql-> user_id:%s", szUserId.c_str() );
 }

void CMysql_::vSelect( IN acl::string szUserId, OUT void** pBody, OUT long* pLen )
{
	const char* pSql_fmt = " select raw from ams_test where user_id = '%s' ;";
	acl::string szSql;
 	szSql.format( pSql_fmt, szUserId.c_str() );

 	int iRet = 0;
 	logger("%s", szSql.c_str() );
	iRet = mysql_real_query( &m_MyConn, szSql.c_str(), szSql.size() );
	if ( !iRet )
	{
		m_Result = mysql_store_result(&m_MyConn);
		if ( m_Result == NULL )
		{
			logger_error( "select failed ...user_id:%s", szUserId.c_str() );
		}
		m_Row = mysql_fetch_row(m_Result);
		unsigned long* uLen = mysql_fetch_lengths(m_Result);
		if (uLen == NULL)
		{	
			logger_error( "select error uLen is NULL ");
		}
		else
		{
			*pBody = malloc( uLen[0] + 1 );
			if (*pBody == NULL)
			{
				logger_error( "malloc error" );
				return ;
			}
			memset(*pBody, 0, uLen[0]);
			memcpy( *pBody, m_Row[0], uLen[0]);

			// szRaw.format("%s", szcRaw);
			*pLen = uLen[0];
			logger("select success...:%ld...sql:%s", uLen[0], szSql.c_str() );

			mysql_free_result(m_Result);
		}
		
	}
	else
	{
		logger_error( "select error ... user_id:%s", szUserId.c_str() );
	}
	
}














