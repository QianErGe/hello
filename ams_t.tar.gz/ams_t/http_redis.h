/*@ brief:封装redis操作
 *@ 
 *@ writer: zhaoq
 *@ date: 2016-07-16
 *@
 */
 #ifndef __HTTP_REDIS_H__
 #define __HTTP_REDIS_H__

 #include <iostream>
 #include "acl_cpp/lib_acl.hpp"
 #include "lib_acl.h"
 #include "stdafx.h"

 class CRedis
 {
 public:
 	// init redis
 	CRedis( const char* pAddr="127.0.0.1:6379", int iConnTimeOut=10, int iRWTimeOut=10 ):m_Conn(pAddr, iConnTimeOut, iRWTimeOut)
 	{
 		// m_Operate(&m_Conn);
 	}	
 	~CRedis(){}

 	// string
 	bool bSetValue( acl::string szKey, acl::string szValue );
 	bool bGetValue( acl::string szKey, acl::string& szValue );

 	// list 
 	bool bRpush( acl::string szKey, acl::string szValue );
 	bool bLpush( acl::string szKey, acl::string szValue );
 	bool bLpop( acl::string szKey, acl::string& szValue );

 	// hash
 	bool bHmSet( IN acl::string szKey, IN acl::string szTransId, IN long iTime, IN long iCount, IN acl::string szDeviceId, IN acl::string szValue );
 	bool bHmSet( IN acl::string szKey, IN long iTime );
 	bool bHmGet( IN acl::string szKey, OUT acl::string& szTransId, OUT long& iTime, OUT long& iCount, OUT acl::string& szDeviceId, OUT acl::string& szValue  );
 	bool bHmUpdate( IN acl::string szKey, IN long iNewTime, IN long iNewCount );
 	bool bHmGet( IN acl::string szKey, IN acl::string szFiled, OUT acl::string& szValue );
 	bool bHmGet( IN acl::string szKey, IN acl::string szFiled, OUT long& iValue );

 	// key
 	bool bExists( acl::string szKey );
 	bool bDelKey( IN acl::string szKey );

 private:
 	// redis 连接
 	acl::redis_client m_Conn;
 	acl::redis_list m_Operate;
 	acl::redis_key m_Redis;
 	acl::redis_hash m_Hash;


 };

 #endif //__HTTP_REDIS_H__
