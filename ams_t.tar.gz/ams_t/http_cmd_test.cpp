/*
 * @brief:服务器接受到机器指令后，将队列中的待执行指令回复给机器
 * @测试程序
 * @writer:zhaoq
 * @date:2016-07-14
 */
 #include "http_cmd_test.h"
 #include <iostream>
 #include <string.h>
 #include <stdlib.h>
 #include <stdio.h>
 #include <time.h>
 using namespace std;
 #define SET_USER_INFO "+SET_USER_INFO"
 #define SET_USER_PRIVILEGE "+SET_USER_PRIVILEGE"
 #define GET_USER_INFO "+GET_USER_INFO"
 #define CLEAR_ENROLL_DATA "1+CLEAR_ENROLL_DATA"
 CCmdTest::CCmdTest()
 {
 	// init
 	m_szCmdCode = "";
 	m_szResponsCode = "OK";
 	m_szTransId = "";
 }
 CCmdTest::~CCmdTest()
 {
 }
 
 /*@ brief: 初始化数据 (redis) 针对每一个设备，初始化测试流程所需要的队列消息
 *@ param szKey  设备id
 *@ return 
 *@ see:
 **/
 void CCmdTest::vInit( acl::string szKey )
 {
 	acl::string szKey1, szKey2;
 	szKey1.format("%s%s", szKey.c_str(), "_1");
 	szKey2.format("%s%s", szKey.c_str(), "_2");

 	acl::string szUserId, szValue;

 	// 初始化redis数据 清空redis，
 	m_Redis1.bDelKey( szKey1 );
 	m_Redis2.bDelKey( szKey2 );

 	// 300 SET_USER_INFO 
 	for ( int i = 1; i <= 300; i++ )
 	{
 		// 获取mysql中的user_id，将device_id作key，user_id与执行命令做value    eg：201605120135 ： 15011576730+SER_USER_INFO
 		m_Mysql.vSelect( i, szUserId );
 		logger("the user->user_id:%s", szUserId.c_str() );
 		szValue.format( "%s%s", szUserId.c_str(), SET_USER_INFO);
 		if ( m_Redis1.bRpush(szKey1, szValue) )
 			logger( "INSERT redis1-> key:%s, value:%s", szKey1.c_str(), szValue.c_str() ); 
 	}
 	// 5 SET_USER_PRIVILEGE
 	srand(time(NULL));
 	for ( int i = 1; i <= 5; i++ )
 	{
 		// 1 随机获取
 		int iNum = (rand()%300)+1;
 		szUserId.clear();szValue.clear();
 		m_Mysql.vSelect( iNum, szUserId );
 		logger("the user->user_id:%s", szUserId.c_str() );
 		// 2 插入redis命令
 		szValue.format( "%s%s", szUserId.c_str(), SET_USER_PRIVILEGE );
 		if ( m_Redis1.bRpush(szKey1, szValue) )
 			logger( "INSERT redis1-> key:%s, value:%s", szKey1.c_str(), szValue.c_str() ); 
 		// 3 获取该用户权限，是否设置成功
 		szValue.clear();
 		szValue.format( "%s%s", szUserId.c_str(), GET_USER_INFO );
 		if ( m_Redis1.bRpush(szKey1, szValue) )
 			logger( "INSERT redis1-> key:%s, value:%s", szKey1.c_str(), szValue.c_str() ); 
 	}
 	// 清除所有数据
 	if ( m_Redis1.bRpush( szKey1, CLEAR_ENROLL_DATA) )
 		logger( "INSERT redis1-> key:%s, value:%s", szKey1.c_str(), szValue.c_str() ); 

 	logger( "init redis end ... " );

 }
 /*@ brief:判断考勤机是否在线18小时
 *@ param szKey  设备id
 *@ return 
 *@ see:
 **/
void CCmdTest::vJudgeTime( acl::string szKey )
{
 	acl::string szKey1, szKey3;
 	szKey1.format("%s%s", szKey.c_str(), "_1");
 	szKey3.format("%s%s", szKey.c_str(), "_3");

 	time_t tCurTime;
	time(&tCurTime);
	long tTime = static_cast<unsigned int>(tCurTime);

 	// 检查当前时间是否大于18小时，是否发送重启命令
 	if ( m_Redis3.bExists(szKey3) )
 	{
 		long iTime = 0;
 		m_Redis3.bHmGet( szKey3, "iTime", iTime );
 		if ( tTime - iTime >= (60*60*18) )
 		{
 			logger("it's been 18 hours ... RESET_FK ...");
 			// 将重启的命令放入redis1中
 			m_Redis1.bRpush( szKey1, "1+RESET_FK" );
 			m_Redis3.bDelKey( szKey3 );
 		}
 		logger( "the online time:%lds", (tTime-iTime) );
 	}
 	else
 	{
 		// 首次接受该考勤机的心跳
 		logger( "appear a new machine device_id:%s", szKey.c_str() );
 		if ( m_Redis3.bHmSet(szKey3, tTime) )
 			logger("insert redis3 success ... key:%s, value:%ld", szKey3.c_str(), tTime );
 		vInit( szKey );
 	}
}
/*@ brief:对外接口，处理http
 *@ param szKey  设备id
 *@ param szBody 组建的消息体
 *@ return 
 *@ see:
 **/
 void CCmdTest::vDealHttp(  acl::string szKey, void** pBody, long* pLen )
 {
 	acl::string szKey1, szKey2;
 	acl::string szValue;
 	szKey1.format("%s%s", szKey.c_str(), "_1");
 	szKey2.format("%s%s", szKey.c_str(), "_2");

 	// 是否在线18小时
 	vJudgeTime(szKey);

 	// 1 检查redis1中是否存在数据
 	if ( !m_Redis1.bExists(szKey1) && !m_Redis2.bExists(szKey2) )
 	{
 		logger( "redis no data ... mabye exec over!" );
 	}
 	else
 	{
 		logger( "redis1 get success...key:%s", szKey.c_str() );
 		if ( !m_Redis2.bExists(szKey2) )
 		{
 			logger( "redis2 do not has the key now get the cmd from redis1:%s...", szKey.c_str() );

 			// 1 get from redis1
 			szValue.clear();
 			m_Redis1.bLpop( szKey1, szValue );
 			logger( "redis1's date : %s", szValue.c_str() );
 			
 			// 2 组建消息体
 			vBuildBody( szKey, szValue, pBody, pLen );
 		}
 		else
 		{
 			logger_error( "attention please ... redis2 has the key:%s...", szKey2.c_str() );
 			// 检查是否超时
 			long iTime = 0;
 			time_t CurTime;
			time(&CurTime);
			long iCurTime = static_cast<unsigned int>(CurTime);
			long iCount = 0;

 			m_Redis2.bHmGet( szKey2, "iTime", iTime );
 			m_Redis2.bHmGet( szKey2, "iCount", iCount );

 			if ( iCurTime - iTime >= 60 )
 			{
 				// 超时1分钟, 若超时1分钟。执行重发
 				if ( iCount >= 3 ) 
 				{
 					logger_error( "[ it's has been repeat too many times...the device:%s should be abandon... ]", szKey.c_str() );
 					m_Redis2.bDelKey( szKey2 );
 					return ;
 				}
 				logger_error("it's has been out of time! send again...");

 				// 1 取出redis1中执行的命令
 				szValue.clear();
 				m_Redis2.bHmGet( szKey2, "szValue", szValue );
 				// 2 重新组建消息体
 				vBuildBody( szKey, szValue, pBody, pLen );
 				// 3 更新redis2时间与次数
 				m_Redis2.bHmUpdate( szKey2, iCurTime, ++iCount );
 				logger( "redis2 update iTime:%ld, iCount:%ld", iCurTime, iCount );
 			}
 			else
 			{
 				// 未超时，此次不做任何处理，等待考勤机的result
 				logger( "it's has not been over time nothing todo ..." );
 				return ;
 			}
 		}
 	}
 }

/*@ brief: 取出队列中的命令，查询相关数据库，组建消息体
 *@ param szKey   设备id
 *@ param szValue 执行命令
 *@ param szBody  组建消息体
 *@ see:
 **/
 void CCmdTest::vBuildBody( acl::string& szKey, acl::string& szValue, void** pBody, long* pLen )
 {
 	// 1 组建redis的key
 	acl::string szKey1, szKey2;
 	szKey1.format("%s%s", szKey.c_str(), "_1");
 	szKey2.format("%s%s", szKey.c_str(), "_2");

 	// 2 截取+ eg: 123553+SET_USER_INFO
 	acl::string szUserId, szCmd;
	std::list<acl::string>& szList = szValue.split( "+" );
	szUserId = szList.front();
	szCmd = szList.back();
	logger( "user_id : %s, CmdCode : %s", szUserId.c_str(), szCmd.c_str() );

	time_t CurTime;
	time(&CurTime);
	long iTime = static_cast<unsigned int>(CurTime);
	m_szTransId.format( "%s+%ld", szKey.c_str(), iTime );
	
	// 4 根据命令不同，组建不同的消息体  写入redis2
	if ( !strcmp(szCmd.c_str(), "SET_USER_INFO") )
	{
		logger("-------------------SET_USER_INFO-------------------");
		// 该数据完全从数据库中获取
		m_Mysql_.vSelect( szUserId, pBody, pLen );
		m_szCmdCode = "SET_USER_INFO";
	}
	else if( !strcmp(szCmd.c_str(), "SET_USER_PRIVILEGE") )
	{
		logger("-------------------SET_USER_PRIVILEGE-------------------");
		// 1 手动将该user_id的数据privilege更换为MANAGER 管理员
		if ( m_Mysql.bUpdate( szUserId, "MANAGER" ) )
			logger( "Update the mysql success user_id :%s", szUserId.c_str() );
		// 2 构建消息体
		acl::string szBody;
		szBody.format("{\"user_id\":\"%s\",\"user_privilege\":\"%s\"}", szUserId.c_str(), "MANAGER" );
		vForDiffBody( szBody, pBody, pLen );
		m_szCmdCode = "SET_USER_PRIVILEGE";

	}
	else if( !strcmp(szCmd.c_str(), "GET_USER_ID_LIST") )
	{
		logger("-------------------GET_USER_ID_LIST-------------------");
		m_szCmdCode = "GET_USER_ID_LIST";
	}
	else if( !strcmp(szCmd.c_str(), "GET_USER_INFO") )
	{
		logger("-------------------GET_USER_INFO-------------------");
		acl::string szBody;
		szBody.format( "{\"user_id\":\"%s\"}", szUserId.c_str() );
		vForDiffBody( szBody, pBody, pLen );
		m_szCmdCode = "GET_USER_INFO";
	}
	else if ( !strcmp(szCmd.c_str(), "DELETE_USER") )
	{
		logger("-------------------DELETE_USER-------------------");
		acl::string szBody;
		szBody.format( "{\"user_id\":\"%s\"}", szUserId.c_str() );
		vForDiffBody( szBody, pBody, pLen );
		m_szCmdCode = "DELETE_USER";
	}
	else if( !strcmp(szCmd.c_str(), "CLEAR_ENROLL_DATA") )
	{
		logger("-------------------CLEAR_ENROLL_DATA-------------------");
		m_szCmdCode = "CLEAR_ENROLL_DATA";
	}
	else if( !strcmp(szCmd.c_str(), "RESET_FK") )
	{
		logger("========================================================");
		logger("===================RESET_FK Test Over===================");
		logger("========================================================");
		m_szCmdCode = "RESET_FK";
		return ;
	}
	// 写入redis2 哈希 key_2 trans_id xxx time xxx count xxx key_1 xxx value_1 xxx
	if ( m_Redis2.bHmSet( szKey2, m_szTransId, iTime, 0, szKey1, szValue ) )
		logger( "insert redis2 success ... key:%s, trans_id:%s, time:%ld, count:%d, redis1_key:%s, redis1_value:%s", szKey2.c_str(), m_szTransId.c_str(), iTime, 1, szKey1.c_str(), szValue.c_str() );
 }

void CCmdTest::vForDiffBody( acl::string& szBody, void** pBody, long* pLen ) 
{
	if ( pBody == NULL || pLen == NULL )
	{
		logger_error( "the param is null ... ");
		return;
	}

	size_t iStrLen = szBody.size() + 1;
	*pBody = malloc( 4+iStrLen+1 );
	if ( *pBody == NULL )
	{
		logger_error( "malloc failed ... " );
		return;
	}
	memset( *pBody, 0, 4+iStrLen+1 );
	memcpy( *pBody, &iStrLen, 4 );

	*pLen = 4+iStrLen;
	memcpy( (char*)*pBody+4, szBody.c_str(), iStrLen );

}





