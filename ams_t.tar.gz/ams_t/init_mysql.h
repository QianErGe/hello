/* 初始化测试程序的mysql
 * 1 从线上数据库中获取300条数据 取出raw字段
 * 2 截取row字段，获取其中的user_id
 * 3 将其中两项，做为新的数据，插入到数据库中
 */
 #ifndef __INIT_MYSQL__H
 #define __INIT_MYSQL__H
 
 #include <iostream>
#include <vector>
#include "stdafx.h"
#include "http_servlet.h"
#include "acl_cpp/stdlib/json.hpp"
#include "http_redis.h"
 #include "http_mysql.h"
 #include <mysql/mysql.h>
 using namespace std;


class CMysql__
 {
 public:
 	CMysql__( const char* pAddr="localhost", const char* pDbName="ams_t", const char* pDbUser="yikaoqin", const char* pDbPasswd="!23$56" )
 	{
 		m_Result = NULL;
 		m_Fd     = NULL;
 		mysql_init(&m_MyConn);
 		if ( mysql_real_connect(&m_MyConn, pAddr, pDbUser, pDbPasswd, pDbName, 3306, NULL, 0) )
 		{

 			mysql_query(&m_MyConn, "SET NAMES GBK");
 			logger( "open mysql:%s, success ... ", pDbName );
 		}
 		else
 		{
 			logger_error( "open mysql:%s, failed ... ", pDbName );
 		}
 	}
 	~CMysql__()
 	{
 		mysql_close(&m_MyConn);
 	}

 	void vSelect( OUT char** pBody, OUT long* pLen , int iNum );
 	void vInsert( IN acl::string szUserId, IN char* pBody, IN long lLen ,IN int iNum );
 	void vInit( int iNum );
 	MYSQL m_MyConn;
 	MYSQL_RES* m_Result;
 	MYSQL_ROW m_Row;
 	MYSQL_FIELD* m_Fd; 
 	CMysql m_Mysql;

	acl::json m_json;			   // json方式解析

 };


 #endif // __INIT_MYSQL__H