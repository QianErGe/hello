/*@ brief:封装mysql操作
 *@ 确保数据库已存在 database：ams_t 
 *@ 
 *@ writer: zhaoq
 *@ date: 2016-07-16
 *@
 */
 #ifndef __HTTP_MYSQL_H__
 #define __HTTP_MYSQL_H__

 #include <iostream>
 #include "acl_cpp/lib_acl.hpp"
 #include "lib_acl.h"
 #include "stdafx.h"
 #include <mysql/mysql.h>
 using namespace std;

 class CMysql
 {
 public:
	CMysql( const char* pAddr="127.0.0.1:3306", const char* pDbName="ams_t", const char* pDbUser="yikaoqin", const char* pDbPasswd="!23$56" ):m_Db(pAddr, pDbName, pDbUser, pDbPasswd)
	{
		if ( m_Db.open() == false )
	 	{
	 		logger_error( "open mysql failed ... " );
	 	}
	 	else
	 	{
	 		logger( "open mysql:%s, success", pDbName );
	 	}
	 	

	}
	~CMysql(){}
	// create
	bool bCreate();
	// insert ams_test
	bool bInsert( acl::string szUserId, acl::string szUserName, acl::string szUserPrivilege, acl::string szUserPhoto, acl::string szEnrollData );
	// insert user_glog
	bool bInsert( acl::string szUserId, acl::string szVerifyMode, acl::string szIoMode, acl::string szIoTime, acl::string szIoImage, int iFlag );

	// delete
	bool bDelete( acl::string szUserId );
	// update
	bool bUpdate( acl::string szUserId, acl::string szUserPrivilege );
	bool bUpdate( int iId, acl::string szUserPrivilege );
	// select
	void vSelect( IN acl::string szUserId, OUT acl::string& szUserName, OUT acl::string& szUserPrivilege, OUT acl::string& szUserPhoto, OUT acl::string& szEnrollData );
	void vSelect( IN acl::string szUserId, OUT acl::string& szUserPrivilege );
	void vSelect( IN int iId, OUT acl::string& szUserId );
private:
	acl::db_mysql m_Db;
 };
 class CMysql_
 {
 public:
 	CMysql_( const char* pAddr="localhost", const char* pDbName="ams_t", const char* pDbUser="yikaoqin", const char* pDbPasswd="!23$56" )
 	{
 		m_Result = NULL;
 		m_Fd     = NULL;
 		mysql_init(&m_MyConn);
 		if ( mysql_real_connect(&m_MyConn, pAddr, pDbUser, pDbPasswd, pDbName, 3306, NULL, 0) )
 		{

 			mysql_query(&m_MyConn, "SET NAMES GBK");
 			logger( "open mysql:%s, success ... ", pDbName );
 		}
 		else
 		{
 			logger_error( "open mysql:%s, failed ... ", pDbName );
 		}
 	}
 	~CMysql_()
 	{
 		mysql_close(&m_MyConn);
 	}

 	void vSelect( IN acl::string szUserId, OUT void** pBody, OUT long* pLen );

 	MYSQL m_MyConn;
 	MYSQL_RES* m_Result;
 	MYSQL_ROW m_Row;
 	MYSQL_FIELD* m_Fd; 

 };

 #endif //__HTTP_MYSQL_H__
