/* @brief：deal according the http 
 * @brief：封装业务处理，解析除去cmd请求之外的所有消息
 * @writer zhaoq
 * @date: 2016.07.13
 */

#ifndef __HTTP_PARSE_H__
#define __HTTP_PARSE_H__

#include <iostream>
#include <vector>
#include "stdafx.h"
#include "http_servlet.h"
#include "acl_cpp/stdlib/json.hpp"
#include "http_redis.h"
#include "http_mysql.h"
#define MAX_BODY_LEN 1024*10

/*@ brief: 解析基类
 *@ question:现在存在的问题是无法根据考勤机发来的消息体过长，无法实现断点续传的功能
 *@
 *@
 */
class CHttpParse
{
public:
	CHttpParse( const char* pBody, unsigned int iLen )
	{
		memset( m_szBody, 0, sizeof(m_szBody) );
	 	if ( pBody != NULL )
	 	{
	 		if ( iLen > sizeof(m_szBody) )
	 		{
	 			iLen = sizeof(m_szBody);
	 		}
	 		strncpy( m_szBody, pBody, iLen );
	 		m_json.update( m_szBody );
		}
	}
 	~CHttpParse(){}

 	/* 纯虚函数，根据不同消息头，负责解析消息体，由子类实现 */
 	virtual bool bParse() = 0;

 	char m_szBody[MAX_BODY_LEN+1]; // 保存传入的消息体
	acl::json m_json;			   // json方式解析

	CMysql m_Mysql;
};

/*
 *@ 当http头为realtime_glog，(用户进行打卡 该逻辑的处理请求是否需要重新创建mysql数据表，该数据结构与新用户注册与登记的数据不一致)
 **/
class CRealtimeGlog : public CHttpParse
{
public:
	CRealtimeGlog( const char* pBody, unsigned int iLen );
	~CRealtimeGlog();

	bool bParse();
};

/*
 *@ 当http头为realtime_enroll_data，(新用户注册，登记)
 **/
class CEnrollData : public CHttpParse
{
public:
	CEnrollData( const char* pBody, unsigned int iLen );
	~CEnrollData();

	bool bParse();
};

/*@brief: 响应http头回复
 *@
 *@
 *@
 **/
class CResponse
{
public:
	CResponse();
	~CResponse();

	/*@ brief:删除redis2中的已存在的key
	 *@ param szKey  设备id
	 *@ 
	 *@ return 
	 *@ see:
	 **/
	bool bDelRedis( acl::string szKey );

	bool bParse( const char* pBody, unsigned int iLen);
	bool bJudgePrivilege( acl::string szUserId, acl::string szPrivilege );
	CRedis m_Redis;
	CMysql m_Mysql;
 	char m_szBody[MAX_BODY_LEN+1]; // 保存传入的消息体
	acl::json m_json;			   // json方式解析
};









#endif // __HTTP_PARSE_H__