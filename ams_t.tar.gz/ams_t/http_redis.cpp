/*@ brief:封装redis操作
 *@ 
 *@ writer: zhaoq
 *@ date: 2016-07-16
 *@
 */

#include "http_redis.h"
/*
bool CRedis::bSetValue( acl::string szKey, acl::string szValue )
{
 	// acl::redis_string m_Operate( &m_Conn );
 	m_Operate.set_client( &m_Conn );
 	m_Operate.clear();
 	if ( m_Operate.set(szKey.c_str(), szValue.c_str()) == false )
 	{
 		const acl::redis_result* pRes = m_Operate.get_result();
 		logger_error( "insert into redis error:%s ...key:%s, value:%s ", pRes?pRes->get_error():"unknown error", szKey.c_str(), szValue.c_str() );
 		return false;
 	}
 	logger( "key:%s, value:%s insert into redis success ...", szKey.c_str(), szValue.c_str() );

 	return true;
}

bool CRedis::bGetValue( acl::string szKey, acl::string& szValue )
{
	// acl::redis_string m_Operate( &m_Conn );
	m_Operate.set_client( &m_Conn );
	m_Operate.clear();
	if ( m_Operate.get(szKey.c_str(), szValue) == false )
	{
		const acl::redis_result* pRes = m_Operate.get_result();
		logger_error( "get from redis error:%s ...key:%s, value:%s ", pRes?pRes->get_error():"unknown error", szKey.c_str(), szValue.c_str() );
		return false;
	}
	logger( "key:%s, value:%s get from redis success ...", szKey.c_str(), szValue.c_str() );

	return true;
}
*/
bool CRedis::bExists( acl::string szKey )
{
	m_Redis.set_client( &m_Conn );
	m_Redis.clear();
	if ( m_Redis.exists(szKey.c_str()) == false )
	{
		logger( "the key:%s not exists ... ", szKey.c_str() );
		return false;
	}
	logger( "the key:%s exists ... ", szKey.c_str() );
	return true;
}
bool CRedis::bDelKey( acl::string szKey )
{
	m_Redis.set_client( &m_Conn );
	m_Redis.clear();
	if ( m_Redis.del_one(szKey.c_str()) < 0 )
	{
		logger( "the key:%s del failed ... ", szKey.c_str() );
		return false;
	}
	logger( "the key:%s del success ... ", szKey.c_str() );
	return true;
}
bool CRedis::bLpush( acl::string szKey, acl::string szValue )
{
	m_Operate.set_client( &m_Conn );
	m_Operate.clear();
	if ( m_Operate.lpush(szKey.c_str(), szValue.c_str(), NULL) <= 0 )
	{
		logger_error( "lpush redis failed ... key:%s, value:%s", szKey.c_str(), szValue.c_str() );
		return false;
	}
	logger( "lpush redis success ... key:%s, value:%s", szKey.c_str(), szValue.c_str() );
	return true;
}
bool CRedis::bRpush( acl::string szKey, acl::string szValue )
{
	m_Operate.set_client( &m_Conn );
	m_Operate.clear();
	if ( m_Operate.rpush(szKey.c_str(), szValue.c_str(), NULL) <= 0 )
	{
		logger_error( "rpush redis failed ... key:%s, value:%s", szKey.c_str(), szValue.c_str() );
		return false;
	}
	logger( "rpush redis success ... key:%s, value:%s", szKey.c_str(), szValue.c_str() );
	return true;
}
bool CRedis::bLpop( acl::string szKey, acl::string& szValue )
{
	m_Operate.set_client( &m_Conn );
	m_Operate.clear();
	szValue.clear();
	if (  m_Operate.lpop(szKey.c_str(), szValue ) <= 0 )
	{
		logger_error( "lpop redis failed ... key:%s, value:%s", szKey.c_str(), szValue.c_str() );
		return false;
	}
	logger( "lpop redis success ... key:%s, value:%s", szKey.c_str(), szValue.c_str() );
	return true;
}

bool CRedis::bHmSet( IN acl::string szKey, IN acl::string szTransId, IN long iTime, IN long iCount, IN acl::string szDeviceId, IN acl::string szValue )
{
	m_Hash.set_client( &m_Conn );
	m_Hash.clear();

	std::map<acl::string, acl::string> attrs;
	acl::string szAttrTransId, szAttrDeviceId, szAttrValue;

	szAttrTransId.format("%s", szTransId.c_str());
	szAttrDeviceId.format("%s", szDeviceId.c_str());
	szAttrValue.format("%s", szValue.c_str());

	attrs["szTransId"]  = szAttrTransId;
	attrs["iTime"]     = iTime;
	attrs["iCount"]    = iCount;
	attrs["szDeviceId"] = szAttrDeviceId;
	attrs["szValue"]    = szAttrValue;

	if ( m_Hash.hmset( szKey.c_str(), attrs) )
	{
		logger( "redis2 hash set success ... key:%s, trans_id:%s, time:%ld, count:%ld, device_id:%s, value:%s ", szKey.c_str(), szTransId.c_str(), iTime, iCount, szDeviceId.c_str(), szValue.c_str() );
		return true;
	}
	else
	{
		logger_error( "redis2 hash set failed ... key:%s, trans_id:%s, time:%ld, count:%ld, device_id:%s, value:%s ", szKey.c_str(), szTransId.c_str(), iTime, iCount, szDeviceId.c_str(), szValue.c_str() );
		return false;
	}
 }

 bool CRedis::bHmSet( IN acl::string szKey, IN long iTime )
 {
 	m_Hash.set_client( &m_Conn );
 	m_Hash.clear();

 	std::map<acl::string, acl::string> attrs;

 	attrs["iTime"] = iTime;
 	
 	if ( m_Hash.hmset( szKey.c_str(), attrs) )
	{
		logger( "redis3 hash set success ... key:%s, time:%ld", szKey.c_str(), iTime );
		return true;
	}
	else
	{
		logger( "redis3 hash set failed ... key:%s, time:%ld", szKey.c_str(), iTime );
		return false;
	}

 }
bool CRedis::bHmGet( IN acl::string szKey, OUT acl::string& szTransId, OUT long& iTime, OUT long& iCount, OUT acl::string& szDeviceId, OUT acl::string& szValue )
{
	m_Hash.set_client( &m_Conn );
	m_Hash.clear();
	szTransId.clear();
	szDeviceId.clear();
	szValue.clear();
	acl::string szTime, szCount;
	szTime.clear();
	szCount.clear();

	bool bRes = true;
	if ( !m_Hash.hget(szKey.c_str(), "szTransId", szTransId) )
		bRes = false;
	if ( !m_Hash.hget(szKey.c_str(), "iTime", szTime) )
		bRes = false;
	if ( !m_Hash.hget(szKey.c_str(), "iCount", szCount) )
		bRes = false;
	if ( !m_Hash.hget(szKey.c_str(), "szDeviceId", szDeviceId) )
		bRes = false;
	if ( !m_Hash.hget(szKey.c_str(), "szValue", szValue) )
		bRes = false;
	iTime = atoi(szTime.c_str());
	iCount = atoi(szCount.c_str());
	return bRes;
}

bool CRedis::bHmGet( IN acl::string szKey, IN acl::string szFiled, OUT acl::string& szValue )
{
	m_Hash.set_client( &m_Conn );
	m_Hash.clear();
	szValue.clear();

	if ( !m_Hash.hget(szKey.c_str(), szFiled.c_str(), szValue) )
		return false;
	return true;
}
bool CRedis::bHmGet( IN acl::string szKey, IN acl::string szFiled, OUT long& iValue )
{
	m_Hash.set_client( &m_Conn );
	m_Hash.clear();
	iValue = 0;
	acl::string szValue;
	szValue.clear();

	if ( !m_Hash.hget(szKey.c_str(), szFiled.c_str(), szValue) )
		return false;
	iValue = atoi(szValue.c_str());
	return true;

}
bool CRedis::bHmUpdate( IN acl::string szKey, IN long iNewTime, IN long iNewCount )
{
	m_Hash.set_client( &m_Conn );
	m_Hash.clear();
	acl::string szValue;
	szValue.clear();

	szValue.format("%ld", iNewTime);
	bool bRes = false;

	if ( m_Hash.hset( szKey.c_str(), "iTime", szValue.c_str() ) < 0 )
		bRes = false;
	
	szValue.clear();
	szValue.format("%ld", iNewCount);
	if ( m_Hash.hset( szKey.c_str(), "iCount", szValue.c_str() ) < 0 )
		bRes = false;
	bRes = true;

	return bRes;	
}
























