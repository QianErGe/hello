#!/bin/sh

valgrind --tool=memcheck --leak-check=yes -v ./ams_t alone ams_t.cf
